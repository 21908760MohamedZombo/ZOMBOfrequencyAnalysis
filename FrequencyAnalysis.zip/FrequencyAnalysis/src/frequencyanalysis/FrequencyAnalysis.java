/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package frequencyanalysis;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class FrequencyAnalysis {

    /**
     * @param args the command line arguments
     */
    
    static <K,V extends Comparable<? super V>> 
            List<Entry<K, V>> entriesSortedByValues(Map<K,V> map) {

    List<Entry<K,V>> sortedEntries = new ArrayList<Entry<K,V>>(map.entrySet());

    Collections.sort(sortedEntries, 
            new Comparator<Entry<K,V>>() {
                @Override
                public int compare(Entry<K,V> e1, Entry<K,V> e2) {
                    return e2.getValue().compareTo(e1.getValue());
                }
            }
    );

    return sortedEntries;
}
    public static void main(String[] args) {
        // TODO code application logic here
      String str = null;
      try {
      File myObj = new File("C:\\Users\\User\\analysis_cipher.txt");
      Scanner myReader = new Scanner(myObj);
      while (myReader.hasNextLine()) {
        str = myReader.nextLine();
        System.out.println(str);
      }
      //System.out.println(data);
      myReader.close();
        } 
    catch (FileNotFoundException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
       
        String strpStr = str.replaceAll("[,.' ]", "");
        //System.out.println(strpStr);
        Map<Character, Integer> map = new HashMap<Character, Integer>();
        
        for(char ch : strpStr.toCharArray()){
            
            if(map.get(ch) == null){
                map.put(ch, 1);
            }
            else{
                map.put(ch, map.get(ch)+1);
            }
        }
        
        map.forEach((key, value)-> {
            //System.out.print(sortedEntries.sort(key + "->" + value+ ", "));
            System.out.print(entriesSortedByValues(map));
        
        });
        
       System.out.println("Option: \n 1) Take replace rule \n 2) Exit");
    }
 }
    
